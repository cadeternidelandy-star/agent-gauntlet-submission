"""Competitor strategy definition for starter-kit agents.

Edit this class to customize behavior without touching runtime code.
"""

from __future__ import annotations

from base_strategy import BaseStrategy


class MyStrategy(BaseStrategy):
    """Default competitor strategy template."""

    # Team identity (shown in Organizer/Dashboard)
    agent_id = "team-hope"
    agent_name = "getstatslight"

    # Text challenge strategy
    text_system_prompt = (
       "You are a statistical analyst and visualization expert. "
        "Explain reasoning step by step and give a concise final answer."
    )
    
    text_temperature = 0.0
    # Reasoning models spend most of this budget thinking before they answer;
    # 1024 cut the roster's default model off before it wrote an answer.
    text_max_tokens = 8192

    # Image challenge strategy
    image_strategy_notes = (
        "Prefer image_edit when an input image is available. Keep rationale concise. "
        "Request standard-resolution output only and avoid HD or 4K images."
    )
def rank_models(self, roster, challenge):
        """Custom model ranking ."""
        # Example: sort models to prioritize 'flash' or specific capabilities
        return sorted(roster, key=lambda m: "flash" not in m.lower())

def pick_model(self, ranked_roster, challenge):
        """Pick the top ranked model from the custom roster."""
        return ranked_roster[0] if ranked_roster else None
